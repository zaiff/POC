package com.dummy.search.ui.theme

import androidx.compose.material3.Typography

// Default typography for now
val Typography = Typography()
